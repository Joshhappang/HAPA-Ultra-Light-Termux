#!/bin/bash
# HAPA LAB — Simulasi Multi-Sig + Auto-Return

echo "============================"
echo "Simulasi HAPA Multi-Sig & Auto-Return"
echo "============================"

TX_FOLDER="testnet_tx_multi"

cd $TX_FOLDER || { echo "Folder $TX_FOLDER tidak ditemukan!"; exit 1; }

for TX_FILE in multisig_msg*.txt; do
    echo
    echo "Menjalankan simulasi untuk $TX_FILE ..."
    
    # Simulasi tanda tangan (hanya ilustrasi)
    echo "Key1 menandatangani $TX_FILE"
    echo "Key2 menandatangani $TX_FILE"
    
    # Cek apakah Key3 menandatangani
    echo "Menunggu Key3... 5 detik"
    for i in 5 4 3 2 1; do
        echo "Menunggu Key3... $i detik tersisa"
        sleep 1
    done
    
    # Auto-return jika Key3 tidak menandatangani
    echo "Key3 tidak menandatangani. Dana ke Key3 dikembalikan ke pengirim (auto-return)."
done

echo
echo "============================"
echo "Simulasi selesai ✅"
echo "============================"
