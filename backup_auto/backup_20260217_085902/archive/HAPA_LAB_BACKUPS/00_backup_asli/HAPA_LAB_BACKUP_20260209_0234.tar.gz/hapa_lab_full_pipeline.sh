#!/bin/bash
# HAPA_LAB HP-friendly full pipeline
# Backup, encrypt, verify, restore

BACKUP_DIR=~/HAPA_LAB
RESTORE_DIR=~/HAPA_LAB_RESTORED
PASSPHRASE='HapaLab2026!Secure'

# 1. Buat backup quantum-ready
BACKUP_FILE="$BACKUP_DIR/HAPA_LAB_BACKUP_$(date +%Y%m%d_%H%M).tar.gz"
echo "Creating backup: $BACKUP_FILE"
tar -czvf "$BACKUP_FILE" -C "$BACKUP_DIR" .
gpg --batch --yes --passphrase "$PASSPHRASE" --symmetric --cipher-algo AES256 "$BACKUP_FILE"

# 2. Buat SHA-256 untuk verifikasi
sha256sum "$BACKUP_FILE.gpg" > "$BACKUP_FILE.gpg.sha256"
echo "SHA-256 created: $BACKUP_FILE.gpg.sha256"

# 3. Restore otomatis
echo "Starting restore..."
gpg --batch --yes --passphrase "$PASSPHRASE" --pinentry-mode loopback --decrypt "$BACKUP_FILE.gpg" -o "$BACKUP_DIR/restored_backup.tar.gz"
mkdir -p "$RESTORE_DIR"
tar -xzvf "$BACKUP_DIR/restored_backup.tar.gz" -C "$RESTORE_DIR"

echo "Restore complete! Files are in $RESTORE_DIR"
