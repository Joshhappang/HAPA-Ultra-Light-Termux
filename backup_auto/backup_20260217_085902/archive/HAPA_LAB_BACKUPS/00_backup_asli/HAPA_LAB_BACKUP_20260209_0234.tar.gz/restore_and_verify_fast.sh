#!/bin/bash
# Fast restore HAPA_LAB backup quantum-ready

BACKUP="$1"
PASSPHRASE="HapaLab2026!Secure"
RESTORE_DIR=~/HAPA_LAB_RESTORED

if [ -z "$BACKUP" ]; then
  echo "Usage: ./restore_and_verify_fast.sh <backup_file.gpg>"
  exit 1
fi

# 1. Verifikasi SHA-256
if [ -f "${BACKUP}.sha256" ]; then
  echo "Verifying SHA-256..."
  sha256sum -c "${BACKUP}.sha256" || { echo "Checksum failed! Abort."; exit 1; }
else
  echo "SHA-256 file not found! Abort."
  exit 1
fi

# 2. Dekripsi backup
echo "Decrypting backup..."
gpg --batch --yes --passphrase "$PASSPHRASE" --decrypt "$BACKUP" -o restored_backup.tar.gz

# 3. Ekstrak ke folder aman
mkdir -p "$RESTORE_DIR"
echo "Extracting files..."
tar -xzvf restored_backup.tar.gz -C "$RESTORE_DIR"

echo "Restore complete! Files are in $RESTORE_DIR"
